/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 
package crud_a3_psc;

import Interface.Principal;

public class CRUD_A3_PSC {

    *
     * @param args the command line arguments
     /
    public static void main(String[] args) {
      new Principal().setVisible(true);
    }
    
} */
