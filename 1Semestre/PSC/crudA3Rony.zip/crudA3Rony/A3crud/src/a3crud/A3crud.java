package a3crud;

import interfaces.Principal;

public class A3crud {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new Principal().setVisible(true);
    }

}
